package io.spring.jpa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class CdeMasterProgramService {

    private final CdeMasterProgramRepository cdeMasterProgramRepository;

    @Autowired
    public CdeMasterProgramService(CdeMasterProgramRepository cdeMasterProgramRepository) {
        this.cdeMasterProgramRepository = cdeMasterProgramRepository;
    }

    public void insertData() {
        String cdeId = "CDE001";
        String cdeName = "Sample CDE Program";
        Date createdDate = new Date();
        Date lastModified = new Date();
        boolean active = true;

        cdeMasterProgramRepository.insertData(cdeId, cdeName, createdDate, lastModified, active);
    }
}

