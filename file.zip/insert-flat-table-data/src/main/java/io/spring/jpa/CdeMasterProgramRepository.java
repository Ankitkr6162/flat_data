package io.spring.jpa;
import java.sql.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import io.spring.jpa.entites.CdeMasterProgram;

@Repository
public interface CdeMasterProgramRepository extends JpaRepository<CdeMasterProgram, Long> {

    @Query("INSERT INTO CdeMasterProgram (cdeId, cdeName, createdDate, lastModified, active) " +
            "VALUES (:cdeId, :cdeName, :createdDate, :lastModified, :active)")
    void insertData(@Param("cdeId") String cdeId,
                    @Param("cdeName") String cdeName,
                    @Param("createdDate") Date createdDate,
                    @Param("lastModified") Date lastModified,
                    @Param("active") boolean active);
}

