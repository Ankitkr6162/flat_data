package io.spring.jpa.entites;

import java.sql.Date;
import javax.persistence.*;

@Entity
@Table(name = "ebo_cde_master_program")
public class CdeMasterProgram {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "cdeid")
    private String cdeId;

    @Column(name = "cdename")
    private String cdeName;

    @Column(name = "created_date")
    private Date createdDate;

    @Column(name = "lastmodified")
    private Date lastModified;

    @Column(name = "active")
    private boolean active;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCdeId() {
		return cdeId;
	}

	public void setCdeId(String cdeId) {
		this.cdeId = cdeId;
	}

	public String getCdeName() {
		return cdeName;
	}

	public void setCdeName(String cdeName) {
		this.cdeName = cdeName;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastModified() {
		return lastModified;
	}

	public void setLastModified(Date lastModified) {
		this.lastModified = lastModified;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public CdeMasterProgram(Long id, String cdeId, String cdeName, Date createdDate, Date lastModified,
			boolean active) {
		super();
		this.id = id;
		this.cdeId = cdeId;
		this.cdeName = cdeName;
		this.createdDate = createdDate;
		this.lastModified = lastModified;
		this.active = active;
	}

   
}

