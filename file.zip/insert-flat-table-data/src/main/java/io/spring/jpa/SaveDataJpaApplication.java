package io.spring.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaveDataJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaveDataJpaApplication.class, args);
	}

}
